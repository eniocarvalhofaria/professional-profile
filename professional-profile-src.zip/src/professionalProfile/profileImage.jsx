import React from 'react'
export default props =>(
    <img className='profile-image'  src={props.src} alt={props.alt}/>
    
)