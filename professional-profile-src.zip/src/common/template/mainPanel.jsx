import React from 'react'
export default props => (
    <div className='main-panel'>
        {props.children}
    </div>
)